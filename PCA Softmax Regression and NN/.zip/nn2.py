import numpy as np

class NN:
    def __init__(self, activation_function, loss_function, hidden_layers=[1024], input_d=784, output_d=10):
        self.weights = []
        self.biases = []
        self.activation_function = activation_function
        self.loss_function = loss_function
        self.beta1 = 0.9
        self.beta2 = 0.999
        self.epsilon = 1e-8
        self.moment_1_W = None
        self.moment_2_W = None
        self.moment_1_b = None
        self.moment_2_b = None
        self.t = 0  # Time step

        # Initialization of weights and biases
        d1 = input_d
        hidden_layers.append(output_d)
        for d2 in hidden_layers:
            self.weights.append(np.random.randn(d2, d1)*np.sqrt(2.0/d1))
            self.biases.append(np.zeros((d2,1)))
            d1 = d2

    def print_model(self):
        """
        This function prints the shapes of weights and biases for each layer.
        """
        print("activation:{}".format(self.activation_function.__class__.__name__))
        print("loss function:{}".format(self.loss_function.__class__.__name__))
        for idx,(w,b) in enumerate(zip(self.weights, self.biases),1):
            print("Layer {}\tw:{}\tb:{}".format(idx, w.shape, b.shape))

    def predict(self, X):
        D = X
        ws = self.weights
        bs = self.biases
        for w,b in zip(ws[:-1], bs[:-1]):
            D = self.activation_function.activate(np.matmul(w,D)+b) 
            # Be careful of the broadcasting here: (d,N) + (d,1) -> (d,N).
        Yhat = np.matmul(ws[-1], D)+bs[-1]
        return np.argmax(Yhat, axis=0)

    def compute_gradients(self, X, Y):
        ws = self.weights
        bs = self.biases
        D_stack = []

        D = X
        D_stack.append(D)
        num_layers = len(ws)
        for idx in range(num_layers-1):
            # TODO 2: Calculate D for forward pass (which is similar to self.predict). 
            # This intermediate results too will then be stored to D_stack.

            ### YOUR CODE HERE ###
            D = self.activation_function.activate(np.matmul(ws[idx], D) + bs[idx])
            D_stack.append(D)

        Yhat = np.matmul(ws[-1], D) + bs[-1]
        training_loss = self.loss_function.loss(Y, Yhat)
        '''
        '''
        grad_bs = []
        grad_Ws = []

        grad = self.loss_function.lossGradient(Y,Yhat)
        grad_b = np.sum(grad, axis=1, keepdims=1)
        grad_W = np.matmul(grad, D_stack[num_layers-1].transpose())
        grad_bs.append(grad_b)
        grad_Ws.append(grad_W)
        for idx in range(num_layers-2, -1, -1):
            # TODO 3: Calculate grad_bs and grad_Ws, which are lists of gradients for b's and w's of each layer. 
            # Take a look at the update step if you are not sure about the format. Notice that we first store the
            # gradients for each layer in a reversed order. The two lists are reversed before returned.

            #1. Update grad for the current layer 

            ### YOUR CODE HERE ###
            grad = self.activation_function.backprop_grad(np.matmul(ws[idx],D_stack[idx]) + bs[idx])*(np.matmul(ws[idx+1].T, grad))

            #2. Calculate grad_b (gradient with respect to b of the current layer)

            ### YOUR CODE HERE ###
            grad_b = np.sum(grad, axis=1, keepdims=1)

            #3. Calculate grad_W (gradient with respect to W of the current layer)

            ### YOUR CODE HERE ###
            grad_W = np.matmul(grad, D_stack[idx].T)
            grad_bs.append(grad_b)
            grad_Ws.append(grad_W)

        grad_bs, grad_Ws = grad_bs[::-1], grad_Ws[::-1] # Reverse the gradient lists
        return training_loss, grad_Ws, grad_bs

    def update(self, grad_Ws, grad_bs, learning_rate):
        if self.moment_1_W is None or self.moment_2_W is None or self.moment_1_b is None or self.moment_2_b is None:
            self.moment_1_W = [np.zeros_like(grad_W) for grad_W in grad_Ws]
            self.moment_2_W = [np.zeros_like(grad_W) for grad_W in grad_Ws]
            self.moment_1_b = [np.zeros_like(grad_b) for grad_b in grad_bs]
            self.moment_2_b = [np.zeros_like(grad_b) for grad_b in grad_bs]

        self.t += 1

        self.moment_1_W = [self.beta1 * m + (1 - self.beta1) * grad_W for m, grad_W in zip(self.moment_1_W, grad_Ws)]
        self.moment_1_b = [self.beta1 * m + (1 - self.beta1) * grad_b for m, grad_b in zip(self.moment_1_b, grad_bs)]
        self.moment_2_W = [self.beta2 * m + (1 - self.beta2) * (grad_W ** 2) for m, grad_W in zip(self.moment_2_W, grad_Ws)]
        self.moment_2_b = [self.beta2 * m + (1 - self.beta2) * (grad_b ** 2) for m, grad_b in zip(self.moment_2_b, grad_bs)]

        # Bias correction
        moment_1_W_corrected = [m / (1 - self.beta1 ** self.t) for m in self.moment_1_W]
        moment_1_b_corrected = [m / (1 - self.beta1 ** self.t) for m in self.moment_1_b]
        moment_2_W_corrected = [m / (1 - self.beta2 ** self.t) for m in self.moment_2_W]
        moment_2_b_corrected = [m / (1 - self.beta2 ** self.t) for m in self.moment_2_b]

        # Update the parameters
        num_layers = len(grad_Ws)
        ws = self.weights
        bs = self.biases
        for idx in range(num_layers):
            ws[idx] -= (learning_rate * moment_1_W_corrected[idx] / (np.sqrt(moment_2_W_corrected[idx]) + self.epsilon))
            bs[idx] -= (learning_rate * moment_1_b_corrected[idx] / (np.sqrt(moment_2_b_corrected[idx]) + self.epsilon))
        self.weights = ws
        self.biases = bs
        return 

class activationFunction:
    def activate(self,X):
        """
        The output of activate should have the same shape as X
        """
        raise NotImplementedError("Abstract class.")

    def backprop_grad(self, grad):
        """
        The output of backprop_grad should have the same shape as X
        """
        raise NotImplementedError("Abstract class.")

class Relu(activationFunction):
    def activate(self,X):
        """
        The output of activate should have the same shape as X
        """
        return X*(X>0)

    def backprop_grad(self, X):
        """
        The output of backprop_grad should have the same shape as X
        """
        return (X>0).astype(np.float64)

class Linear(activationFunction):
    def activate(self,X):
        """
        The output of activate should have the same shape as X
        """
        return X
    def backprop_grad(self,X):
        """
        The output of backprop_grad should have the same shape as X
        """
        return np.ones(X.shape, dtype=np.float64)

class LossFunction:
    def loss(self, Y, Yhat):
        """
        The true values are in the vector Y; the predicted values are
        in Yhat; compute the loss associated with these predictions.
        """
        raise NotImplementedError("Abstract class.")

    def lossGradient(self, Y, Yhat):
        """
        The true values are in the vector Y; the predicted values are in 
        Yhat; compute the gradient of the loss with respect to Yhat
        """
        raise NotImplementedError("Abstract class.")

class SquaredLoss(LossFunction):
    def loss(self, Y, Yhat):
        """
        The true values are in the vector Y; the predicted values are
        in Yhat; compute the loss associated with these predictions.
        """
        # TODO 0: loss function for squared loss.

        ### YOUR CODE HERE ###
        diff = Yhat - Y
        norm = np.linalg.norm(diff)
        return (norm ** 2) * (0.5/Yhat.shape[1])


    def lossGradient(self, Y, Yhat):
        """
        The true values are in the vector Y; the predicted values are in 
        Yhat; compute the gradient of the loss with respect to Yhat
        """
        #TODO 1: gradient for squared loss.

        ### YOUR CODE HERE ###
        diff = Yhat - Y
        return(diff/Yhat.shape[1])


class CELoss(LossFunction):
    def loss(self, Y, Yhat):
        """
        The true values are in the vector Y; the predicted values are
        in Yhat; compute the loss associated with these predictions.
        """
        #TODO 4: loss function for cross-entropy loss.

        ### NOT REQUIRED FOR THIS PROJ, YOU CAN DO IT FOR FUN ###
        raise NotImplementedError("Implement CELoss.")

    def lossGradient(self, Y, Yhat):
        """
        The true values are in the vector Y; the predicted values are in 
        Yhat; compute the gradient of the loss with respect to Yhat, which
        has the same shape of Yhat and Y.
        """
        #TODO 5: gradient for cross-entropy loss.

        ### NOT REQUIRED FOR THIS PROJ, YOU CAN DO IT FOR FUN ###
        raise NotImplementedError("Implement CELoss")
